package com.producer.service;



import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ProduserApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProduserApplication.class, args);
	}


}
