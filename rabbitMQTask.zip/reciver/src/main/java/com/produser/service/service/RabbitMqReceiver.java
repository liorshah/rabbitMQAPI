package com.produser.service.service;

import com.produser.service.domain.User;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.annotation.RabbitListenerConfigurer;
import org.springframework.amqp.rabbit.listener.RabbitListenerEndpointRegistrar;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class RabbitMqReceiver implements RabbitListenerConfigurer {
	
	@Autowired
	private RestTemplate restTemplate;
	private static final Logger logger = LoggerFactory.getLogger(RabbitMqReceiver.class);

	@Override
	public void configureRabbitListeners(RabbitListenerEndpointRegistrar rabbitListenerEndpointRegistrar) {
	}

	@RabbitListener(queues = "${spring.rabbitmq.queue}")
	public void receivedMessage(User user) {
		logger.info("User Details Received is.. " + user);
		postUser(user);
	}
	
	private void postUser(User user)
	{
	    final String uri = "http://localhost:9093/v1/user";
	    restTemplate.postForObject( uri, user, User.class);
	    logger.info("User Post");
	}
}